This code can be used to replicate the work described in section 5 of the paper 'Directed Spectrum Measures Improve Latent Network Models Of Neural Populations'.

STEPS:

1) Simulated dataset generation
A small example dataset of simulated recordings is provided in the files 'sim.mat' and 'sim.json'.
To generate a new dataset of 10000 simulated recordings, run the script genToyNetwork.m in MATLAB.

2) Calculation of directed spectrum and comparison measures
To calculate the directed spectrum, pairwise directed spectrum and all comparison measures, run:
	saveFeatures('sim.mat')
In order to calculate granger causality features, please download the MVGC toolbox from https://users.sussex.ac.uk/~lionelb/MVGC/
saveFeatures.m take an optional second parameter, which is a structure that allows the user to select which measures to calculate, in addition to other options.
For more details see the header comment in saveFeatures.m.

3) Train NMF models
To train NMF models on the measures calculated in step 2 use train_NMF_DS.py.
The train_NMF_DS.py script takes 3 arguments: the path of the datafile used in steps 1 & 2, the measure to be used, and the name of the new modelfile that will be saved.
The second argument should match the name of a variable in the datafile.
Ex: python3 train_NMF_DS.py sim.mat directedSpectrum ds_nmf
For more details see the header docstring in train_NMF_DS.py.

4) Evaluate correlation between true and estimated scores
Open get_corr.ipynb in a jupyter notebook session.
Edit the MODELFILE variable in the first cell to match the name of the saved model file from step 3.
Run the whole notebook, and the last cell will output the correlation between true and estimated scores for that model.